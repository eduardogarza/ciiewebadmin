<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Welcome to Something</title>
</head>
<body>
<h1>Welcome to Something</h1>
<p>This is Login page</p>
</body>
</html>