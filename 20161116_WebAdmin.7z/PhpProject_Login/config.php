<?php
    $database_user = "Host";
    $database_name = "proyecto_ciie_db";
    $database_pass = "j:RzcEY9,763M!SQ5H0st";
    $database_table_usuarios = "usuarios";
    $database_host = "localhost";
    
    $db = new mysqli($database_host, $database_user, $database_pass, $database_name);
    if($db===FALSE){
        die("<strong>Not connected to database.</strong>");
    }
    else
    {
        //echo "Connected to database.";
    }

?>
