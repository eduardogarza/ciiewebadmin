<?php
include 'config.php';
$error=''; //Variable to Store error message;
if(isset($_POST['submit'])){
 if(empty($_POST['user']) || empty($_POST['pass'])){
 $error = "Username or Password is Invalid";
 }
 else
 {
 //Define $user and $pass
 $user=$_POST['user'];
 $pass=$_POST['pass'];

 //sql query to fetch information of registerd user and finds user match.
 $query = mysqli_query($db, "SELECT * FROM usuarios WHERE Contrasena='$pass' AND Email='$user'");
 
 $rows = mysqli_num_rows($query);
 if($rows == 1){
 header("Location: welcome.php"); // Redirecting to other page
 }
 else
 {
 $error = "Username of Password is Invalid";
 }
 mysqli_close($db); // Closing connection
 }
}
 
?>