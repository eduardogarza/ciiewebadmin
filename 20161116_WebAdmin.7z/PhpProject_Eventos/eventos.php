<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <?php require("config.php"); ?>	
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>CIIE</title>
        <!-- BOOTSTRAP STYLES-->
        <link href="assets/css/bootstrap.css" rel="stylesheet" />
        <!-- FONTAWESOME STYLES-->
        <link href="assets/css/font-awesome.css" rel="stylesheet" />
        <!-- MORRIS CHART STYLES-->
        <!-- CUSTOM STYLES-->
        <link href="assets/css/custom.css" rel="stylesheet" />
        <!-- GOOGLE FONTS-->
        <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
        <!-- TABLE STYLES-->
        <link href="assets/js/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
    </head>

    <body>
            <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">Admin</a>
                <img alt="" src="Territorium.png" /></div>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;">  <a href="#" class="btn btn-danger square-btn-adjust">Logout</a> </div>
        </nav>   
		   
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                    <img src="assets/img/find_user.png" class="user-image img-responsive"/>
					</li>
				
					
                    <li>
                        <a  href="eventos.php">Ver Eventos</a>
                    </li>
                   <li>
                        <a  href="editareventos.php">Editar Eventos</a>
                    </li>
                    <li>
                        <a  href="tab-panel.html"> LINK </a>
                    </li>
                    <li>
                        <a  href="tab-panel.html"> LINK </a>
                    </li>
                    <li>
                        <a  href="tab-panel.html"> LINK </a>
                    </li>
						   <li  >
                        &nbsp;</li>	
                    <li  >
                    </li>				
					
					                   
                    <li></li>
                    <li></li>
                </ul>
               
            </div>
            
        </nav>  
		
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>Ver Eventos
                       
                    </div>
                </div>
				 
                 <hr />
               
            <div class="row">
                <div class="col-md-12">
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table border="1">
                                        <tr>
                                            <th> ID Evento </th>
                                            <th> Titulo </th>
                                            <th> Tema </th>
                                            <th> Descripcion </th>
                                            <th> Idioma </th>
                                            <th> Liga de Registro </th>
                                            <th> Fecha inicio </th>
                                            <th> Fecha fin </th>
                                            <th> Semaforo </th>
                                            <th> Salon </th>
                                            <th> Tipo de evento </th>
                                        </tr>
                                    <?php
                                    $result = $db->query("SELECT * FROM eventos");
                                        if($result->num_rows>0){
                                                while($row = $result->fetch_assoc()){
                                                ?>
                                                    <tr>
                                            <td> <?php echo $row['idEventos'];?> </td>
                                            <td> <?php echo $row['Titulo'];?> </td>
                                            <td> <?php echo $row['Tema'];?> </td>
                                            <td> <?php echo $row['Descripcion'];?> </td>
                                            <td> <?php echo $row['Idioma'];?> </td>
                                            <td> <?php echo $row['ligaDeRegistro'];?> </td>
                                            <td> <?php echo $row['fechaInicio'];?> </td>
                                            <td> <?php echo $row['fechaFin'];?> </td>
                                            <td> <?php echo $row['semaforo'];?> </td>
                                            <td> <?php echo $row['Salon_idSalon'];?> </td>
                                            <td> <?php echo $row['Tipo_Eventos_idTipo_Eventos'];?> </td>
                                                    
                                                    

                                                    </tr>        
                                        <?php
                                                }
                                        }
                                        else
                                        {
                                            ?>
                                    <tr>
                                        <th colspan ="2"> There is no data found! </th>
                                    </tr>
                                    <?php
                                        }
                                                                            

                                        $result->free();
                                    ?>
                                </table>
                </div>
            </div>

        </div>
               
    </div>
            </div>

    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
    <!-- DATA TABLE SCRIPTS -->
    <script src="assets/js/dataTables/jquery.dataTables.js"></script>
    <script src="assets/js/dataTables/dataTables.bootstrap.js"></script>
    <script>
    $(document).ready(function () {
    $('#dataTables-example').dataTable();
    });
    </script>
    <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    <?php //mysql_close($db); ?>
    </body>
    </html>
