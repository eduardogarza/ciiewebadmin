<?php

//Database connection
include 'config.php';

//Get ID from entry
if(isset($_Get['edit_id'])){
    $sql = "SELECT * FROM eventos WHERE idEventos= " .$_Get['edit_id'];
    $result = mysqli_query($db, $sql);
    //$row = mysqli_fetch_array($result);
    $row= $result->fetch_assoc();
}

//Update information
if(isset($_POST['btn-update'])){
 $titulo = $_POST['Titulo'];
 $tema = $_POST['Tema'];
 $descripcion = $_POST['Descripcion'];
 $idioma = $_POST['Idioma'];
 $ligaderegistro = $_POST['ligaDeRegistro'];
 $fechainicio = $_POST['fechaInicio'];
 $fechafin = $_POST['fechaFin'];
 $Semaforo = $_POST['semaforo'];

   $update = "UPDATE eventos SET Titulo='$titulo', Tema='$tema', Descripcion='$descripcion', Idioma='$idioma' ,  ligaDeRegistro='$ligaderegistro', fechaInicio='$fechainicio', fechaFin='$fechafin', semaforo ='$Semaforo'  WHERE idEventos = ".$_Get['edit_id'];
    $up = mysqli_query($db, $update);
    if(!isset($sql)){
        die("Error sql" .mysqli_connect_error());
    }
    else{
        header("location: editareventos.php");
    }
}
?>


<!-- Create Edit Form -->

<!doctype html>
<html>
<body>
    <form  method = "post">
        <h1> Editar informacion </h1>
      
        <label> Titulo: </label> <input type="text" name="Titulo" placeholder="Titulo" value="<?php echo $row['Titulo']; ?>"><br/><br/>
        <label> Tema: </label> <input type="text" name="tema" placeholder="Tema" value="<?php echo $row['Tema']; ?>"><br/><br/>
        <label> Descripcion: </label> <input type="text" name="descripcion" placeholder="Descripcion" value="<?php echo $row['Descripcion']; ?>"><br/><br/>
        <label> Idioma: </label> <input type="text" name="idioma" placeholder="Idioma" value="<?php echo $row['Idioma']; ?>"><br/><br/>
        <label> ligaDeRegistro: </label> <input type="text" name="ligaderegistro" placeholder="ligaDeRegistro" value="<?php echo $row['ligaDeRegistro']; ?>"><br/><br/>
        <label> fechaInicio: </label> <input type="text" name="fechainicio" placeholder="fechaInicio" value="<?php echo $row['fechaInicio']; ?>"><br/><br/>
        <label> fechaFin: </label> <input type="text" name="fechafin" placeholder="fechaFin" value="<?php echo $row['fechaFin']; ?>"><br/><br/>
        <label> Semaforo: </label> <input type="text" name="semaforo" placeholder="Semaforo" value="<?php echo $row['Semaforo']; ?>"><br/><br/>


        <button type="submit" name="btn_update" id="btn_update" onclick="update()"><strong> Update </strong> </button></a>
        

        <a href="editareventos.php"><button type="button" value="button">Cancel</button></a>
    </form>

    
    <!--Alert for updating-->
    <script>
        function update(){
            var x;
            if(confirm("Exitoso") ===true){
                x="update";
            }
        }
        
        </script>
</body>
</html>

    