<?php
//Database connection
include 'config.php';
//include 'index.php';

//Update information
if(isset($_POST['btn-update'])){

 $titulo = $_POST['Titulo'];
 $tema = $_POST['Tema'];
 $descripcion = $_POST['Descripcion'];
 $idioma = $_POST['Idioma'];
 $ligaderegistro = $_POST['ligaDeRegistro'];
 $fechainicio = $_POST['fechaInicio'];
 $fechafin = $_POST['fechaFin'];
 $Semaforo = $_POST['semaforo'];

 $insert = "INSERT INTO `proyecto_ciie_db`.`eventos`  VALUES ('', '$titulo', '$tema', '$descripcion', '$idioma', '$ligaderegistro', '$fechainicio', '$fechafin', '$Semaforo' , '1', '1')";

 $up = mysqli_query($db, $insert);
 if(!isset($up)){
 die ("Error $sql" .mysqli_connect_error());
 }
 else
 {
 header("location: index.php");
 }
}
?>
<!-- Create Edit Form -->
<!doctype html>
<html>
<body>
    <form method = "post">
        <h1> Editar informacion </h1>
        <label> Titulo: </label> <input type="text" name="Titulo" placeholder="Titulo" value="<?php echo $row['titulo']; ?>"><br/><br/>
        <label> Tema: </label> <input type="text" name="Tema" placeholder="Tema" value="<?php echo $row['tema']; ?>"><br/><br/>
        <label> Descripcion: </label> <input type="text" name="Descripcion" placeholder="Descripcion" value="<?php echo $row['descripcion']; ?>"><br/><br/>
        <label> Idioma: </label> <input type="text" name="Idioma" placeholder="Idioma" value="<?php echo $row['idioma']; ?>"><br/><br/>
        <label> ligaDeRegistro: </label> <input type="text" name="ligaDeRegistro" placeholder="ligaDeRegistro" value="<?php echo $row['ligaderegistro']; ?>"><br/><br/>
        <label> fechaInicio: </label> <input type="date" name="fechaInicio" placeholder="fechainicio" value="<?php echo $row['fechainicio']; ?>"><br/><br/>
        <label> fechaFin: </label> <input type="date" name="fechaFin" placeholder="fechaFin" value= "<?php echo $row['fechafin']; ?>"><br/><br/> 
        <label> Semaforo: </label> <input type="text" name="semaforo" placeholder="1-Verde 2-Amarillo 3-Rojo" value="<?php echo $row['Semaforo']; ?>"><br/><br/>
<br/><br/>
        <button type="submit" name="btn-update" id="btn-update" onClick="update()"><strong>Insert</strong><a href="editareventos.php"></button>
        <a href="editareventos.php"><button type="button" value="button">Go Back</button></a>
</form>
<a href="editareventos.php"><button type="button" value="button">Cancel</button></a>
</form>


<!-- Alert for Updating -->
<script>
function update(){
 var x;
 if(confirm("Datos insertados") === true){
 x= "update";
 }
}
</script>
</body>
</html>

    
