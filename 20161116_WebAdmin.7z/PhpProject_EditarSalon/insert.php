<?php
//Database connection
include 'config.php';
//include 'index.php';

//Update information
if(isset($_POST['btn-update'])){
 $capacity = $_POST['capacidad'];
 $classroom = $_POST['aula'];
 $update = "INSERT INTO `proyecto_ciie_db`.`salon` (`Capacidad`, `Aula`) VALUES ('$capacity', '$classroom')";
 $up = mysqli_query($db, $update);
 if(!isset($up)){
 die ("Error $sql" .mysqli_connect_error());
 }
 else
 {
 header("location: index.php");
 }
}
?>


<!-- Create Edit Form -->

<!doctype html>
<html>
<body>
    <form method = "post">
        <h1> Edit Information </h1>
        <label> Capacidad: </label> <input type="text" name="capacidad" placeholder="Capacidad"><br/><br/>
        <label> Aula: </label> <input type="text" name="aula" placeholder="Aula"><br/><br/>    
        <button type="submit" name="btn-update" id="btn-update" onClick="update()"><strong>Insert</strong></button>
<a href="index.php"><button type="button" value="button">Cancel</button></a>
</form>
<!-- Alert for Updating -->
<script>
function update(){
 var x;
 if(confirm("Data sucessfully inserted") === true){
 x= "update";
 }
}
</script>
</body>
</html>






