<?php
//Database connection
include 'config.php';
//include 'index.php';

//Update information
if(isset($_POST['btn-update'])){
 $name = $_POST['nombre'];
 $surname = $_POST['apellidos'];
 $email = $_POST['email'];
 $password = $_POST['contrasena'];
 $update = "INSERT INTO `proyecto_ciie_db`.`usuarios` (`Nombre`, `Apellidos`, `Email`, `Contrasena`) VALUES ('$name', '$surname', '$email', '$password')";
 $up = mysqli_query($db, $update);
 if(!isset($up)){
 die ("Error $sql" .mysqli_connect_error());
 }
 else
 {
 header("location: index.php");
 }
}
?>


<!-- Create Edit Form -->

<!doctype html>
<html>
<body>
    <form method = "post">
        <h1> Editar informacion </h1>
        <label> Nombre: </label> <input type="text" name="nombre" placeholder="Nombre"><br/><br/>
        <label> Apellidos: </label> <input type="text" name="apellidos" placeholder="Apellidos"><br/><br/>
        <label> Email: </label> <input type="text" name="email" placeholder="Email"><br/><br/>
        <label> Contrasena: </label> <input type="text" name="contrasena" placeholder="Contrasena"><br/><br/>
        <button type="submit" name="btn-update" id="btn-update" onClick="update()"><strong>Insert</strong></button>
<a href="EditarUsuarios_index.php"><button type="button" value="button">Cancel</button></a>
</form>
<!-- Alert for Updating -->
<script>
function update(){
 var x;
 if(confirm("Data sucessfully inserted") === true){
 x= "update";
 }
}
</script>
</body>
</html>

    
