<?php

//Database connection
include 'config.php';
//include 'index.php';

//Get ID from entry
if(isset($_GET['edit_id'])){
 $sql = "SELECT * FROM `proyecto_ciie_db`.`usuarios` WHERE idUsuarios = " .$_GET['edit_id'];
 $result = mysqli_query($db, $sql);
 $row = mysqli_fetch_array($result);
}

//Update information
if(isset($_POST['btn-update'])){
 $name = $_POST['nombre'];
 $surname = $_POST['apellidos'];
 $email = $_POST['email'];
 $password = $_POST['contrasena'];
 $update = "DELETE FROM `proyecto_ciie_db`.`usuarios` WHERE `idUsuarios`=" .$_GET['edit_id'];
 $up = mysqli_query($db, $update);
 if(!isset($sql)){
 die ("Error $sql" .mysqli_connect_error());
 }
 else
 {
 header("location: index.php");
 }
}
?>


<!-- Create Edit Form -->

<!doctype html>
<html>
<body>
    <form method = "post">
        <h1> Delete Entry </h1>
        <label> Nombre: </label> <input type="text" name="nombre" placeholder="Nombre" value="<?php echo $row['Nombre']; ?>"><br/><br/>
        <label> Apellidos: </label> <input type="text" name="apellidos" placeholder="Apellidos" value="<?php echo $row['Apellidos']; ?>"><br/><br/>
        <label> Email: </label> <input type="text" name="email" placeholder="Email" value="<?php echo $row['Email']; ?>"><br/><br/>
        <label> Contrasena: </label> <input type="text" name="contrasena" placeholder="Contrasena" value="<?php echo $row['Contrasena']; ?>"><br/><br/>
        <button type="submit" name="btn-update" id="btn-update" onClick="update()"><strong>Delete</strong></button>
<a href="EditarUsuarios_index.php"><button type="button" value="button">Cancel</button></a>
</form>
<!-- Alert for Updating -->
<script>
function update(){
 var x;
 if(confirm("Data sucessfully deleted") === true){
 x= "update";
 }
}
</script>
</body>
</html>

    