<?php

//Database connection
include 'config.php';
//include 'index.php';

//Get ID from entry
if(isset($_GET['edit_id'])){
 $sql = "SELECT * FROM `proyecto_ciie_db`.`conferencistas` WHERE idConferencistas = " .$_GET['edit_id'];
 $result = mysqli_query($db, $sql);
 $row = mysqli_fetch_array($result);
}

//Update information
if(isset($_POST['btn-update'])){
 $name = $_POST['nombre'];
 $surname = $_POST['apellidos'];
 $email = $_POST['email'];
 $password = $_POST['contrasena'];
 $position = $_POST['puesto'];
 $company = $_POST['empresa'];
 $country = $_POST['pais'];
 $update = "UPDATE `proyecto_ciie_db`.`conferencistas` SET `Nombre`='$name', `Apellidos`='$surname', `Email`='$email', `Contrasena`='$password', `Puesto`='$position', `Empresa`='$company', `Pais`='$country' WHERE `idConferencistas`=" .$_GET['edit_id'];
 $up = mysqli_query($db, $update);
 if(!isset($sql)){
 die ("Error $sql" .mysqli_connect_error());
 }
 else
 {
 header("location: index.php");
 }
}
?>


<!-- Create Edit Form -->

<!doctype html>
<html>
<body>
    <form method = "post">
        <h1> Editar informacion </h1>
        <label> Nombre: </label> <input type="text" name="nombre" placeholder="Nombre" value="<?php echo $row['Nombre']; ?>"><br/><br/>
        <label> Apellidos: </label> <input type="text" name="apellidos" placeholder="Apellidos" value="<?php echo $row['Apellidos']; ?>"><br/><br/>
        <label> Email: </label> <input type="text" name="email" placeholder="Email" value="<?php echo $row['Email']; ?>"><br/><br/>
        <label> Contrasena: </label> <input type="text" name="contrasena" placeholder="Contrasena" value="<?php echo $row['Contrasena']; ?>"><br/><br/>
  <label> Puesto: </label> <input type="text" name="puesto" placeholder="Puesto" value="<?php echo $row['Puesto']; ?>"><br/><br/>
        <label> Empresa: </label> <input type="text" name="empresa" placeholder="Empresa" value="<?php echo $row['Empresa']; ?>"><br/><br/>
        <label> Pais: </label> <input type="text" name="pais" placeholder="Pais" value="<?php echo $row['Pais']; ?>"><br/><br/>

        <button type="submit" name="btn-update" id="btn-update" onClick="update()"><strong>Update</strong></button>
<a href="index.php"><button type="button" value="button">Cancel</button></a>
</form>
<!-- Alert for Updating -->
<script>
function update(){
 var x;
 if(confirm("Updated data Sucessfully") === true){
 x= "update";
 }
}
</script>
</body>
</html>


